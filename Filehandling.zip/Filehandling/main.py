import os
import datetime
from os.path import join

lookFor = input("Enter file name: ")
filename = ""
for root, dirs, files in os.walk('C:\\'):
    print("searching", root)
    if lookFor in files:
        print("found: %s" % join(root, lookFor))
        filename = join(root, lookFor)
        break

print("The File Name: "+lookFor)
print("size of file  {}byte".format(os.path.getsize(filename)))
m_time = os.path.getmtime(filename)
# convert timestamp into DateTime object
dt_m = datetime.datetime.fromtimestamp(m_time)
print("File Last Modify Date and Time")
print(dt_m)


